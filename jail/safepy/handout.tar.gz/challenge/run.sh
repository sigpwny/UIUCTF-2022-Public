#!/bin/sh

cd /home/user/sympy
/usr/bin/python3 -u main.py