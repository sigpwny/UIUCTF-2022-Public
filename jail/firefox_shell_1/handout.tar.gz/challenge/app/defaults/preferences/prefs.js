/* global pref:false */

pref('toolkit.defaultChromeURI', 'chrome://app/content/main.xhtml');
pref('browser.dom.window.dump.enabled', true);
pref('devtools.console.stdout.chrome', true);

pref('browser.cache.disk.enable', false);
pref('app.update.enabled', false);
pref('app.update.auto', false);
